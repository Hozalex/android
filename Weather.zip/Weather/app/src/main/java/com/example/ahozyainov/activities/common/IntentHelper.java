package com.example.ahozyainov.activities.common;

public class IntentHelper {

    public static final String EXTRA_CITY_POSITION = "city_position";
    public static final String EXTRA_CHECKBOX_PRESSURE = "checkBoxPresure";
    public static final String EXTRA_CHECKBOX_TOMORROW = "checkBoxTomorrow";
    public static final String EXTRA_CHECKBOX_WEEK = "checkBoxWeek";
    public static final String EXTRA_CITY_ID = "cityId";
    public static final String EXTRA_SHARED_WEATHER = "sharedText";

}
