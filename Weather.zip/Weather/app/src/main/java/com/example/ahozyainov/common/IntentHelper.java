package com.example.ahozyainov.common;

public class IntentHelper {

    public static final String EXTRA_CITY_NAME = "city_name";
    public static final String EXTRA_CHECKBOX_PRESSURE = "checkBoxPresure";
    public static final String EXTRA_CHECKBOX_TOMORROW = "checkBoxTomorrow";
    public static final String EXTRA_CHECKBOX_WEEK = "checkBoxWeek";
    public static final String EXTRA_CITY_ID = "cityId";
    public static final String EXTRA_SHARED_WEATHER = "sharedText";
    public static final String EXTRA_ARRAY_CITIES = "citiesArray";

}
